<?php if (!defined('FW')) die('Forbidden');

$manifest = array();

$manifest['name'] = __( 'Builder', 'fw' );
$manifest['version'] = '1.2.10';
$manifest['github_update'] = 'ThemeFuse/Unyson-Builder-Extension';
$manifest['github_repo'] = 'https://github.com/ThemeFuse/Unyson-Builder-Extension';
$manifest['uri'] = 'http://manual.unyson.io/en/latest/extension/builder/index.html';
$manifest['author'] = 'ThemeFuse';
$manifest['author_uri'] = 'http://themefuse.com/';
